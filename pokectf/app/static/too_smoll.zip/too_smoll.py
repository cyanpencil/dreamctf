from Crypto.Util.number import bytes_to_long

with open("flag.txt", "rb") as f:
    flag = bytes_to_long(f.read())

e = 0x10001
res = []
for n in range(1, 1000):
    res.append(pow(flag, e, n))
print(res)
