#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    int password = 0;
    char name[50] = {0};
    read(0, name, 0x50);
    if (password == 0xdeadb33f) {
        puts("Wow! How did you do that???");
        puts("Here, have a shell ;)");
        
        system("/bin/sh");
    } else {
        puts("I guess you're not cool enough....");
    }
}
